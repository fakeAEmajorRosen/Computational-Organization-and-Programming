This is a GBA game that requires the player to avoid collision with the enemy and reach the destination.

1) START:
Hit the ENTER key to start the game.

2) RESTART ANYTIME:
Hit the backspace key to restart the game anytime.

3) Characters:
    - Player: you are the yellow square in the game. You can use up, down, left, right key to control it. 
    - Enemy: the moving mushroom.
    - Destination: The Pikachu picture.

4) Rules:
    - To WIN the game, you must move your character (the yelow square) until you hit the pikachu picture
     (destination) in the bottom right corner of the screen.
    - You will have 3 lives for each game. 
    - Each time you hit your enemy(the mushroom), you will lose 1 life.
    - You LOSE when losing all your 3 lives.

5) Details and Requirements:
    - Full Screen images: START, WIN, LOSE states
    - Small images: PLAY states
    - Text: EVERY STATES (the text "Lives: #" will change when you collide)
    - Moving object and Collision: PLAY states


