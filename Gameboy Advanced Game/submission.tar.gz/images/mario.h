/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=40x40 mario mario.jpg 
 * Time-stamp: Thursday 11/05/2020, 21:46:47
 * 
 * Image Information
 * -----------------
 * mario.jpg 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MARIO_H
#define MARIO_H

extern const unsigned short mario[1600];
#define MARIO_SIZE 3200
#define MARIO_LENGTH 1600
#define MARIO_WIDTH 40
#define MARIO_HEIGHT 40

#endif

