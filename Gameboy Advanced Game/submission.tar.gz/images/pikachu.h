/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=50x50 pikachu pikachu.jpg 
 * Time-stamp: Friday 11/06/2020, 04:53:17
 * 
 * Image Information
 * -----------------
 * pikachu.jpg 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PIKACHU_H
#define PIKACHU_H

extern const unsigned short pikachu[2500];
#define PIKACHU_SIZE 5000
#define PIKACHU_LENGTH 2500
#define PIKACHU_WIDTH 50
#define PIKACHU_HEIGHT 50

#endif

