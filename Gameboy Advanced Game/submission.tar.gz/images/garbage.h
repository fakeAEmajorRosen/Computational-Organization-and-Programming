/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 garbage garbage.png 
 * Time-stamp: Friday 11/06/2020, 04:44:53
 * 
 * Image Information
 * -----------------
 * garbage.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GARBAGE_H
#define GARBAGE_H

extern const unsigned short garbage[38400];
#define GARBAGE_SIZE 76800
#define GARBAGE_LENGTH 38400
#define GARBAGE_WIDTH 240
#define GARBAGE_HEIGHT 160

#endif

