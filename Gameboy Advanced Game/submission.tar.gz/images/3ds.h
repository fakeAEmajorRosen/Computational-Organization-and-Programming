/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 3ds 3ds.jpg 
 * Time-stamp: Thursday 11/05/2020, 17:25:35
 * 
 * Image Information
 * -----------------
 * 3ds.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DS_H
#define DS_H

extern const unsigned short ds[38400];
#define DS_SIZE 76800
#define DS_LENGTH 38400
#define DS_WIDTH 240
#define DS_HEIGHT 160

#endif

