/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 gticon gticon.png 
 * Time-stamp: Friday 11/06/2020, 07:34:36
 * 
 * Image Information
 * -----------------
 * gticon.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GTICON_H
#define GTICON_H

extern const unsigned short gticon[38400];
#define GTICON_SIZE 76800
#define GTICON_LENGTH 38400
#define GTICON_WIDTH 240
#define GTICON_HEIGHT 160

#endif

